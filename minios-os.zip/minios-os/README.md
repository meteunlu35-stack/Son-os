# MiniOS (Linux + C++ masaustu)

Linux cekirdegi + Buildroot ile kucuk bir sistem. Acilista C++17 ile yazilmis
`minios-shell` masaustu acilir: ana ekran, pencereler, gorev cubugu, saat.

Uygulamalar: Dosyalar (gercek dosya sistemi), Terminal (her Linux komutu),
Notlar (kaydeder), Gorevler (/proc'tan surec ve bellek, surec sonlandirma),
Yilan, Hesap Makinesi, Ayarlar (duvar kagidi, yeniden baslat, kapat),
Asistan (asagiya bak).

## Asistan (Guvercin Bot, Siri gibi ana yapay zeka)
Her yerden acilir: F1, gorev cubugundaki Asistan dugmesi, ana ekrandaki kutu,
ya da bos masaustunde yazmaya baslamak. 4 mod: Normal, Ciddi, Eglenceli, Agent.
- Yerel komutlar (internet/anahtar gerekmez): 'terminal ac', 'notlara yaz: ...',
  'saat kac', 'bellek', 'duvar kagidi gece', 'komut: ls /', 'sistemi kapat'.
- Anahtar butonuna Groq API anahtarini yazarsan her konuda sohbet eder ve
  [[EYLEM:...]] etiketleriyle sistemi kontrol eder: uygulama ac/kapat, komut
  calistir, not yaz, dosya oku, surec sonlandir, duvar kagidi, yeniden baslat, kapat.
- Tehlikeli eylemler (komut, surec sonlandirma, kapatma) Onayla/Iptal ister.
  'Onay' dugmesiyle kapatabilirsin; kapatirsan yapay zeka onaysiz komut calistirir.
- Anahtar sadece bellekte tutulur, diske yazilmaz. Sohbet /root/.guvercin_sohbet'e kaydedilir.
- Test: MINIOS_FAKE_LLM='...' ile sahte cevap, MINIOS_KEY ile anahtar verilebilir.

## Calistirma (Linux, build-essential + qemu-system-x86_64 kurulu)
    ./build.sh   # ilk derleme yaklasik 20-40 dk
    ./run.sh

## Hizli deneme (Linux kurmadan, sadece derleyici)
    make test    # /tmp/minios.ppm ekran goruntusu uretir

## Dosyalar
- src/main.cpp   masaustu kabugu (framebuffer + evdev, bagimlilik yok)
- src/font.h     8x16 bitmap font (otomatik uretildi)
- package/       Buildroot paketi, minios.fragment ayarlar, kernel.fragment
- overlay/       acilista kabugu baslatan init betigi

## Sinirlar
Tarayici ve uygulama dukkani henuz yok. Sesle konusma (mikrofon/hoparlor) yok. Terminal komutlari
5 saniyede zaman asimina ugrar, etkilesimli programlar (vim, top) calismaz.
