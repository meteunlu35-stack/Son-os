// MiniOS Shell - Linux framebuffer masaustu (C++17, bagimlilik yok)
// Gercek mod: /dev/fb0 + /dev/input/event*   Test modu: --test W H (komutlar stdin'den, PPM cikti)
#include <algorithm>
#include <atomic>
#include <thread>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <dirent.h>
#include <fcntl.h>
#include <functional>
#include <linux/fb.h>
#include <linux/input.h>
#include <memory>
#include <poll.h>
#include <signal.h>
#include <string>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>
#include "font.h"

static int64_t g_fake = 0;  // test modunda zaman ilerletme
static int64_t nowms() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1000LL + t.tv_nsec / 1000000 + g_fake; }

struct Rect { int x, y, w, h; bool in(int px, int py) const { return px >= x && py >= y && px < x + w && py < y + h; } };
static const uint32_t BG = 0x131d2a, BAR = 0x1b2838, FG = 0xe6edf3, MUT = 0x8b9bb0, ACC = 0x2dd4bf, SIDE = 0x101a26, LINE = 0x2a3d54, RED = 0xe5484d;

// ---------- Cizim ----------
struct Canvas {
  int w, h; std::vector<uint32_t> px; Rect clip;
  Canvas(int W, int H) : w(W), h(H), px((size_t)W * H), clip{0, 0, W, H} {}
  void fill(Rect r, uint32_t c) {
    int x0 = std::max(r.x, clip.x), y0 = std::max(r.y, clip.y), x1 = std::min(r.x + r.w, clip.x + clip.w), y1 = std::min(r.y + r.h, clip.y + clip.h);
    for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[(size_t)y * w + x] = c;
  }
  void rrect(Rect r, int rad, uint32_t c) {
    for (int y = 0; y < r.h; y++) for (int x = 0; x < r.w; x++) {
      int dx = x < rad ? rad - x : (x >= r.w - rad ? x - (r.w - rad - 1) : 0), dy = y < rad ? rad - y : (y >= r.h - rad ? y - (r.h - rad - 1) : 0);
      if (dx * dx + dy * dy <= rad * rad) fill({r.x + x, r.y + y, 1, 1}, c);
    }
  }
  static bool has(uint32_t cp) { int lo = 0, hi = FONT_N - 1; while (lo <= hi) { int m = (lo + hi) / 2; if (FONT_CP[m] == cp) return true; if (FONT_CP[m] < cp) lo = m + 1; else hi = m - 1; } return false; }
  static const uint8_t* glyph(uint32_t cp) {
    int lo = 0, hi = FONT_N - 1;
    while (lo <= hi) { int m = (lo + hi) / 2; if (FONT_CP[m] == cp) return FONT_BM[m]; if (FONT_CP[m] < cp) lo = m + 1; else hi = m - 1; }
    return glyph('?');
  }
  int text(int x, int y, const std::string& s, uint32_t col, int sc = 1) {
    size_t i = 0; int cx = x;
    while (i < s.size()) {
      uint32_t cp = (uint8_t)s[i++];
      if (cp >= 0xC0) { int n = cp >= 0xF0 ? 3 : cp >= 0xE0 ? 2 : 1; cp &= (0x3F >> n); while (n-- && i < s.size()) cp = (cp << 6) | ((uint8_t)s[i++] & 0x3F); }
      const uint8_t* g = glyph(cp);
      for (int r = 0; r < 16; r++) for (int b = 0; b < 8; b++) if (g[r] & (0x80 >> b)) fill({cx + b * sc, y + r * sc, sc, sc}, col);
      cx += 8 * sc;
    }
    return cx - x;
  }
};
static int tw(const std::string& s) { int n = 0; for (unsigned char c : s) if ((c & 0xC0) != 0x80) n++; return n * 8; }
static std::string cut(const std::string& s, int cols) { std::string o; int n = 0; for (size_t i = 0; i < s.size(); i++) { if (((unsigned char)s[i] & 0xC0) != 0x80) { if (n == cols) break; n++; } o += s[i]; } return o; }
static void button(Canvas& c, Rect r, const std::string& t, bool hot = false) { c.rrect(r, 6, hot ? ACC : BAR); c.text(r.x + (r.w - tw(t)) / 2, r.y + (r.h - 16) / 2, t, hot ? 0x07201c : FG); }

// ---------- Uygulama arayuzu ----------
struct Shell;
struct App {
  std::string title; int dw = 440, dh = 320; Shell* sh = nullptr; Rect R{0, 0, 0, 0};
  virtual ~App() {}
  virtual void draw(Canvas&, Rect) = 0;
  virtual void down(int, int) {}
  virtual void key(int, int) {}
  virtual void wheel(int) {}
  virtual void tick() {}
};
enum { K_UP = 1000, K_DOWN, K_LEFT, K_RIGHT, K_ESC, K_F1 };

static std::vector<std::string> runCmd(const std::string& cmd, int secs = 5) {
  int p[2]; if (pipe(p)) return {"pipe hatasi"};
  pid_t pid = fork();
  if (pid == 0) { setpgid(0, 0); dup2(p[1], 1); dup2(p[1], 2); close(p[0]); close(p[1]); int n = open("/dev/null", O_RDONLY); dup2(n, 0); execl("/bin/sh", "sh", "-c", cmd.c_str(), (char*)0); _exit(127); }
  close(p[1]); std::string out; char b[1024]; time_t t0 = time(0);
  for (;;) {
    pollfd pf{p[0], POLLIN, 0}; int r = poll(&pf, 1, 200);
    if (r > 0) { ssize_t n = read(p[0], b, sizeof b); if (n <= 0) break; out.append(b, n); if (out.size() > 65536) break; }
    if (time(0) - t0 >= secs) { out += "\n[zaman asimi]"; break; }
  }
  close(p[0]); kill(-pid, SIGKILL); waitpid(pid, nullptr, 0);
  std::vector<std::string> L; std::string cur;
  for (char ch : out) { if (ch == '\n') { L.push_back(cur); cur.clear(); } else if (ch == '\t') cur += "    "; else if (ch != '\r') cur += ch; }
  if (!cur.empty()) L.push_back(cur);
  return L;
}

// ---------- Terminal ----------
struct Term : App {
  std::vector<std::string> L; std::string in;
  Term() { title = "Terminal"; dw = 560; dh = 340; L.push_back("MiniOS terminal. Her Linux komutu calisir (ls, ps, free, uname -a ...)."); }
  void draw(Canvas& c, Rect r) override {
    R = r; c.fill(r, 0x0b1118); int rows = (r.h - 28) / 16, cols = (r.w - 12) / 8;
    int start = std::max(0, (int)L.size() - rows);
    for (int i = start; i < (int)L.size(); i++) c.text(r.x + 6, r.y + 4 + (i - start) * 16, cut(L[i], cols), 0xcfd8e3);
    c.text(r.x + 6, r.y + r.h - 20, cut("# " + in + ((nowms() / 500) % 2 ? "_" : " "), cols), ACC);
  }
  void key(int code, int ch) override {
    if (ch == '\n') { L.push_back("# " + in); if (in == "clear") L.clear(); else if (!in.empty()) { auto o = runCmd(in); L.insert(L.end(), o.begin(), o.end()); } in.clear(); while (L.size() > 500) L.erase(L.begin()); }
    else if (ch == '\b') { if (!in.empty()) in.pop_back(); }
    else if (ch >= 32 && ch < 127) in += (char)ch;
    (void)code;
  }
};

// ---------- Notlar ----------
struct Notes : App {
  std::string text, path; std::string msg;
  Notes(const std::string& p = "") { title = p.empty() ? "Notlar" : "Notlar - " + p.substr(p.rfind('/') + 1); dw = 460; dh = 340; path = p.empty() ? "/root/notlar.txt" : p;
    if (!p.empty()) { if (FILE* f = fopen(p.c_str(), "r")) { char b[1024]; size_t n; while ((n = fread(b, 1, sizeof b, f)) > 0 && text.size() < 65536) text.append(b, n); fclose(f); } } }
  void draw(Canvas& c, Rect r) override {
    R = r; c.fill(r, BG); c.fill({r.x, r.y, r.w, 34}, SIDE); button(c, {r.x + 8, r.y + 4, 90, 26}, "Kaydet", true);
    c.text(r.x + 108, r.y + 9, cut(msg.empty() ? path : msg, (r.w - 116) / 8), MUT);
    int cols = (r.w - 16) / 8, rows = (r.h - 44) / 16, row = 0, col = 0; std::vector<std::string> lines(1);
    for (char ch : text) { if (ch == '\n' || col >= cols) { lines.emplace_back(); col = 0; if (ch == '\n') continue; } lines.back() += ch; col++; }
    int start = std::max(0, (int)lines.size() - rows);
    for (int i = start; i < (int)lines.size(); i++, row++) c.text(r.x + 8, r.y + 40 + row * 16, lines[i] + ((i == (int)lines.size() - 1 && (nowms() / 500) % 2) ? "_" : ""), FG);
  }
  void down(int x, int y) override { if (Rect{R.x + 8, R.y + 4, 90, 26}.in(x, y)) { FILE* f = fopen(path.c_str(), "w"); if (!f) { path = "/tmp/notlar.txt"; f = fopen(path.c_str(), "w"); } if (f) { fwrite(text.data(), 1, text.size(), f); fclose(f); msg = "Kaydedildi: " + path; } else msg = "Kaydedilemedi"; } }
  void key(int, int ch) override { if (ch == '\b') { if (!text.empty()) text.pop_back(); } else if (ch == '\n' || (ch >= 32 && ch < 127)) text += (char)ch; }
};

// ---------- Dosyalar ----------
struct Files : App {
  std::string path = "/"; struct E { std::string n; bool d; long sz; }; std::vector<E> es; int scroll = 0;
  Files() { title = "Dosyalar"; dw = 500; dh = 360; if (access("/root", R_OK) == 0) path = "/root"; load(); }
  void load() {
    es.clear(); scroll = 0; if (path != "/") es.push_back({"..", true, 0});
    if (DIR* d = opendir(path.c_str())) { std::vector<E> t; while (dirent* e = readdir(d)) { std::string n = e->d_name; if (n == "." || n == "..") continue; struct stat st{}; stat((path + "/" + n).c_str(), &st); t.push_back({n, S_ISDIR(st.st_mode), (long)st.st_size}); } closedir(d);
      std::sort(t.begin(), t.end(), [](const E& a, const E& b) { return a.d != b.d ? a.d > b.d : a.n < b.n; }); es.insert(es.end(), t.begin(), t.end()); }
  }
  void draw(Canvas& c, Rect r) override {
    R = r; c.fill(r, BG); c.fill({r.x, r.y, r.w, 28}, SIDE); c.text(r.x + 8, r.y + 6, cut(path, (r.w - 16) / 8), ACC);
    int rows = (r.h - 30) / 22;
    for (int i = 0; i < rows && i + scroll < (int)es.size(); i++) { const E& e = es[i + scroll]; int y = r.y + 30 + i * 22;
      if (e.d) c.text(r.x + 10, y + 3, "■", ACC); c.text(r.x + 26, y + 3, cut(e.n, (r.w - 120) / 8), e.d ? 0x7db4ff : FG);
      if (!e.d) { char b[32]; snprintf(b, sizeof b, "%ld B", e.sz); c.text(r.x + r.w - tw(b) - 10, y + 3, b, MUT); } }
  }
  void down(int x, int y) override {
    int i = (y - R.y - 30) / 22 + scroll; if (y < R.y + 30 || i < 0 || i >= (int)es.size()) return; (void)x; const E e = es[i];
    if (e.d) { if (e.n == "..") path = path.substr(0, std::max<size_t>(1, path.rfind('/'))); else path += (path == "/" ? "" : "/") + e.n; load(); }
    else openFile(path + "/" + e.n);
  }
  void wheel(int d) override { scroll = std::max(0, std::min((int)es.size() - 1, scroll - d)); }
  void key(int code, int) override { if (code == K_UP) wheel(1); if (code == K_DOWN) wheel(-1); }
  void openFile(const std::string& p);
};

// ---------- Gorev Yoneticisi ----------
struct Tasks : App {
  struct P { int pid; std::string name; long rss; }; std::vector<P> ps; int64_t last = -9999; std::string mem, load; double frac = 0; std::vector<Rect> rr;
  Tasks() { title = "Gorev Yoneticisi"; dw = 480; dh = 360; }
  void refresh() {
    ps.clear(); if (DIR* d = opendir("/proc")) { while (dirent* e = readdir(d)) { int pid = atoi(e->d_name); if (!pid) continue; char b[256]; std::string name = "?"; long rss = 0;
      snprintf(b, sizeof b, "/proc/%d/comm", pid); if (FILE* f = fopen(b, "r")) { if (fgets(b, sizeof b, f)) { name = b; while (!name.empty() && name.back() == '\n') name.pop_back(); } fclose(f); }
      snprintf(b, sizeof b, "/proc/%d/statm", pid); if (FILE* f = fopen(b, "r")) { long a, r2; if (fscanf(f, "%ld %ld", &a, &r2) == 2) rss = r2 * 4; fclose(f); }
      ps.push_back({pid, name, rss}); } closedir(d); }
    std::sort(ps.begin(), ps.end(), [](const P& a, const P& b) { return a.rss > b.rss; });
    struct sysinfo si; if (sysinfo(&si) == 0) { double tot = si.totalram * (double)si.mem_unit / 1048576, fr = si.freeram * (double)si.mem_unit / 1048576; frac = (tot - fr) / tot; char b[96]; snprintf(b, sizeof b, "RAM %.0f / %.0f MB   yuk %.2f", tot - fr, tot, si.loads[0] / 65536.0); mem = b; }
  }
  void draw(Canvas& c, Rect r) override {
    R = r; if (nowms() - last > 1000) { refresh(); last = nowms(); }
    c.fill(r, BG); c.text(r.x + 10, r.y + 8, mem, FG); c.fill({r.x + 10, r.y + 30, r.w - 20, 8}, BAR); c.fill({r.x + 10, r.y + 30, (int)((r.w - 20) * frac), 8}, ACC);
    c.text(r.x + 10, r.y + 48, "PID", MUT); c.text(r.x + 70, r.y + 48, "SUREC", MUT); c.text(r.x + r.w - 110, r.y + 48, "BELLEK", MUT);
    rr.clear(); int rows = (r.h - 72) / 20;
    for (int i = 0; i < rows && i < (int)ps.size(); i++) { int y = r.y + 68 + i * 20; char b[32]; snprintf(b, sizeof b, "%d", ps[i].pid);
      c.text(r.x + 10, y, b, MUT); c.text(r.x + 70, y, cut(ps[i].name, 22), FG); snprintf(b, sizeof b, "%ld KB", ps[i].rss); c.text(r.x + r.w - 110, y, b, FG); c.text(r.x + r.w - 24, y, "×", RED); rr.push_back({r.x + r.w - 32, y - 2, 28, 20}); }
  }
  void down(int x, int y) override { for (size_t i = 0; i < rr.size(); i++) if (rr[i].in(x, y) && ps[i].pid > 1 && ps[i].pid != getpid()) { kill(ps[i].pid, SIGTERM); last = -9999; } }
};

// ---------- Yilan ----------
struct Snake : App {
  static const int N = 24, M = 16, S = 16; std::vector<std::pair<int, int>> sn; int dx = 1, dy = 0, ndx = 1, ndy = 0, fx = 5, fy = 5, score = 0; bool dead = false; int64_t t = 0;
  Snake() { title = "Yilan"; dw = N * S + 2; dh = M * S + 62; reset(); }
  void reset() { sn = {{7, 7}, {6, 7}, {5, 7}}; dx = ndx = 1; dy = ndy = 0; score = 0; dead = false; t = nowms(); fx = rand() % N; fy = rand() % M; }
  void tick() override {
    if (dead || nowms() - t < 130) return; t = nowms(); dx = ndx; dy = ndy; int nx = sn[0].first + dx, ny = sn[0].second + dy;
    if (nx < 0 || ny < 0 || nx >= N || ny >= M) { dead = true; return; } for (auto& p : sn) if (p.first == nx && p.second == ny) { dead = true; return; }
    sn.insert(sn.begin(), {nx, ny}); if (nx == fx && ny == fy) { score++; fx = rand() % N; fy = rand() % M; } else sn.pop_back();
  }
  void draw(Canvas& c, Rect r) override {
    R = r; c.fill(r, BG); char b[64]; snprintf(b, sizeof b, "Skor: %d%s", score, dead ? "  - bitti, tikla/yon tusu" : ""); c.text(r.x + 8, r.y + 6, b, FG);
    Rect g{r.x + 1, r.y + 30, N * S, M * S}; c.fill(g, 0x0b1118); c.fill({g.x + fx * S, g.y + fy * S, S - 2, S - 2}, RED);
    for (auto& p : sn) c.fill({g.x + p.first * S, g.y + p.second * S, S - 2, S - 2}, 0x22c55e);
  }
  void down(int x, int y) override { if (dead) { reset(); return; } int hx = R.x + 1 + sn[0].first * S, hy = R.y + 30 + sn[0].second * S; int ddx = x - hx, ddy = y - hy;
    if (std::abs(ddx) > std::abs(ddy)) { if (ddx > 0 && dx != -1) { ndx = 1; ndy = 0; } else if (ddx < 0 && dx != 1) { ndx = -1; ndy = 0; } } else { if (ddy > 0 && dy != -1) { ndx = 0; ndy = 1; } else if (ddy < 0 && dy != 1) { ndx = 0; ndy = -1; } } }
  void key(int code, int ch) override {
    if (dead) { reset(); return; }
    if ((code == K_UP || ch == 'w') && dy != 1) { ndx = 0; ndy = -1; } if ((code == K_DOWN || ch == 's') && dy != -1) { ndx = 0; ndy = 1; }
    if ((code == K_LEFT || ch == 'a') && dx != 1) { ndx = -1; ndy = 0; } if ((code == K_RIGHT || ch == 'd') && dx != -1) { ndx = 1; ndy = 0; }
  }
};

// ---------- Hesap Makinesi ----------
static double calcEval(const std::string& s, bool& ok) {
  size_t i = 0; ok = true; std::function<double()> ex, tm, nm;
  nm = [&]() -> double { if (i < s.size() && s[i] == '(') { i++; double v = ex(); if (i < s.size() && s[i] == ')') i++; return v; } size_t j = i; if (j < s.size() && s[j] == '-') j++; while (j < s.size() && (isdigit((unsigned char)s[j]) || s[j] == '.')) j++; if (j == i) { ok = false; return 0; } double v = atof(s.substr(i, j - i).c_str()); i = j; return v; };
  tm = [&]() { double v = nm(); while (i < s.size() && (s[i] == '*' || s[i] == '/')) { char o = s[i++]; double r = nm(); v = o == '*' ? v * r : v / r; } return v; };
  ex = [&]() { double v = tm(); while (i < s.size() && (s[i] == '+' || s[i] == '-')) { char o = s[i++]; double r = tm(); v = o == '+' ? v + r : v - r; } return v; };
  double v = ex(); if (i != s.size()) ok = false; return v;
}
struct Calc : App {
  std::string e; const char* K[20] = {"C", "(", ")", "/", "7", "8", "9", "*", "4", "5", "6", "-", "1", "2", "3", "+", "0", ".", "<", "="};
  Calc() { title = "Hesap Makinesi"; dw = 300; dh = 380; }
  void press(const std::string& k) { if (k == "C") e.clear(); else if (k == "<") { if (!e.empty()) e.pop_back(); } else if (k == "=") { bool ok; double v = calcEval(e, ok); char b[64]; snprintf(b, sizeof b, "%.9g", v); e = ok ? b : "Hata"; } else { if (e == "Hata") e.clear(); e += k; } }
  Rect kr(int i) { return {R.x + 10 + (i % 4) * 70, R.y + 70 + (i / 4) * 52, 64, 46}; }
  void draw(Canvas& c, Rect r) override { R = r; c.fill(r, BG); c.rrect({r.x + 10, r.y + 10, r.w - 20, 50}, 8, 0x0e1621); std::string t = e.empty() ? "0" : e; c.text(r.x + r.w - 20 - tw(t) * 2, r.y + 20, t, FG, 2); for (int i = 0; i < 20; i++) button(c, kr(i), K[i], i == 19); }
  void down(int x, int y) override { for (int i = 0; i < 20; i++) if (kr(i).in(x, y)) press(K[i]); }
  void key(int, int ch) override { if (ch == '\n') press("="); else if (ch == '\b') press("<"); else if (ch && strchr("0123456789+-*/.()", ch)) press(std::string(1, (char)ch)); }
};

// ---------- Ayarlar ----------
struct Settings : App {
  Settings() { title = "Ayarlar"; dw = 400; dh = 300; }
  void draw(Canvas& c, Rect r) override;
  void down(int x, int y) override;
};

// ---------- Asistan: yardimci fonksiyonlar ----------
static uint32_t u8next(const std::string& s, size_t& i) {
  uint32_t cp = (uint8_t)s[i++];
  if (cp >= 0xC0) { int n = cp >= 0xF0 ? 3 : cp >= 0xE0 ? 2 : 1; cp &= (0x3F >> n); while (n-- && i < s.size()) cp = (cp << 6) | ((uint8_t)s[i++] & 0x3F); }
  return cp;
}
static void u8put(std::string& o, uint32_t cp) {
  if (cp < 0x80) o += (char)cp;
  else if (cp < 0x800) { o += (char)(0xC0 | (cp >> 6)); o += (char)(0x80 | (cp & 0x3F)); }
  else if (cp < 0x10000) { o += (char)(0xE0 | (cp >> 12)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
  else { o += (char)(0xF0 | (cp >> 18)); o += (char)(0x80 | ((cp >> 12) & 0x3F)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
}
static std::string norm(const std::string& s) {  // kucuk harf + Turkce karakterleri ASCII'ye indir
  std::string o; size_t i = 0;
  while (i < s.size()) { uint32_t cp = u8next(s, i);
    if (cp < 0x80) o += (char)tolower((int)cp);
    else switch (cp) { case 0xE7: case 0xC7: o += 'c'; break; case 0x11F: case 0x11E: o += 'g'; break; case 0x131: case 0x130: o += 'i'; break;
      case 0xF6: case 0xD6: o += 'o'; break; case 0x15F: case 0x15E: o += 's'; break; case 0xFC: case 0xDC: o += 'u'; break; default: break; } }
  return o;
}
static std::string clean(const std::string& s) {  // fontta olmayan karakterleri (emoji vb.) at
  std::string o; size_t i = 0;
  while (i < s.size()) { uint32_t cp = u8next(s, i);
    if (cp == 0x2019 || cp == 0x2018) cp = '\''; else if (cp == 0x201C || cp == 0x201D) cp = '"'; else if (cp == 0x2014) cp = '-';
    if (cp == '\n') o += '\n'; else if (cp == '\t') o += ' '; else if (cp < 32) continue; else if (cp < 0x80 || Canvas::has(cp)) u8put(o, cp); }
  for (size_t p; (p = o.find("**")) != std::string::npos;) o.erase(p, 2);
  return o;
}
static std::string jsonEsc(const std::string& s) {
  std::string o; for (unsigned char c : s) { if (c == '"') o += "\\\""; else if (c == '\\') o += "\\\\"; else if (c == '\n') o += "\\n"; else if (c == '\r') o += "\\r"; else if (c == '\t') o += "\\t"; else if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; } else o += (char)c; }
  return o;
}
static bool jsonStrAt(const std::string& s, size_t p, std::string& out) {
  if (p >= s.size() || s[p] != '"') return false; out.clear();
  for (size_t i = p + 1; i < s.size(); i++) { char c = s[i];
    if (c == '"') return true;
    if (c != '\\') { out += c; continue; }
    if (++i >= s.size()) break; char e = s[i];
    if (e == 'n') out += '\n'; else if (e == 't') out += '\t'; else if (e == 'r') {}
    else if (e == 'u' && i + 4 < s.size()) { uint32_t cp = strtoul(s.substr(i + 1, 4).c_str(), nullptr, 16); i += 4;
      if (cp >= 0xD800 && cp < 0xDC00 && i + 6 < s.size() && s[i + 1] == '\\' && s[i + 2] == 'u') { uint32_t lo = strtoul(s.substr(i + 3, 4).c_str(), nullptr, 16); cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00); i += 6; }
      u8put(out, cp); }
    else out += e; }
  return false;
}
static std::string extractReply(const std::string& r, bool& ok) {
  ok = false; std::string v; size_t m = r.find("\"message\""), e = r.find("\"error\""), np = std::string::npos;
  if (e != np && (m == np || e < m)) { size_t q = r.find("\"message\":", e); if (q != np) { size_t p = r.find('"', q + 10); if (p != np && jsonStrAt(r, p, v)) return "API hatasi: " + v; } return "API hatasi"; }
  if (m == np) return r.empty() ? "Bos cevap (internet var mi?)" : "Beklenmeyen cevap";
  size_t c = r.find("\"content\":", m); if (c == np) return "Icerik yok";
  size_t p = c + 10; while (p < r.size() && r[p] == ' ') p++;
  if (jsonStrAt(r, p, v)) { ok = !v.empty(); return v.empty() ? "Bos cevap" : v; }
  return "Icerik okunamadi";
}
static void writeSecret(const std::string& path, const std::string& d) { int fd = open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0600); if (fd >= 0) { if (write(fd, d.data(), d.size()) < 0) {} close(fd); } }
static int entryFor(const std::string& n) {  // uygulama takma adlari (normalize metin icinde ara)
  static const std::pair<const char*, int> T[] = {{"komut satiri", 1}, {"terminal", 1}, {"konsol", 1}, {"dosya", 0}, {"notlar", 2}, {"not", 2}, {"gorev", 3}, {"surec", 3}, {"yilan", 4}, {"oyun", 4}, {"hesap", 5}, {"ayar", 6}, {"asistan", 7}};
  for (auto& t : T) if (n.find(t.first) != std::string::npos) return t.second;
  return -1;
}
static void wrapInto(std::vector<std::pair<std::string, uint32_t>>& out, const std::string& text, int cols, uint32_t col) {
  std::vector<std::string> paras(1); for (char c : text) { if (c == '\n') paras.emplace_back(); else paras.back() += c; }
  for (auto& p : paras) {
    std::string line, word; auto flush = [&]() { out.push_back({line, col}); line.clear(); };
    auto addWord = [&]() { if (word.empty()) return; int lw = tw(word) / 8, ll = tw(line) / 8;
      while (lw > cols) { if (!line.empty()) flush(); out.push_back({cut(word, cols), col}); size_t k = 0, n = 0; while (k < word.size() && n < (size_t)cols) { u8next(word, k); n++; } word = word.substr(k); lw = tw(word) / 8; }
      if (ll + (line.empty() ? 0 : 1) + lw > cols) flush(); if (!line.empty()) line += ' '; line += word; word.clear(); };
    for (char c : p) { if (c == ' ') addWord(); else word += c; } addWord(); flush();
  }
}

struct Shell;
struct Req { std::atomic<int> st{0}; std::string out; };
struct Assistant : App {
  struct Msg { bool user; std::string t; }; struct Pend { std::string act, par, desc; };
  std::vector<Msg> chat; std::vector<std::pair<std::string, std::string>> hist; std::vector<Pend> pend;
  std::string in, apiKey, name, lastUser, histFile; int mode = 0, scroll = 0; bool needConfirm = true, keyMode = false, busy = false; std::shared_ptr<Req> req;
  Rect rMode[4], rKey{0, 0, 0, 0}, rConf{0, 0, 0, 0}, rClear{0, 0, 0, 0}, rOk{0, 0, 0, 0}, rNo{0, 0, 0, 0};
  Assistant() {
    title = "Asistan"; dw = 580; dh = 440; histFile = access("/root", W_OK) == 0 ? "/root/.guvercin_sohbet" : "/tmp/.guvercin_sohbet";
    if (const char* k = getenv("MINIOS_KEY")) apiKey = k;
    if (FILE* f = fopen(histFile.c_str(), "r")) { char b[8192]; while (fgets(b, sizeof b, f)) { std::string l = b; while (!l.empty() && l.back() == '\n') l.pop_back(); if (l.size() < 2) continue; std::string t = l.substr(2); for (auto& ch : t) if (ch == '\x1f') ch = '\n'; chat.push_back({l[0] == 'u', t}); } fclose(f); }
    for (size_t i = chat.size() > 16 ? chat.size() - 16 : 0; i < chat.size(); i++) hist.push_back({chat[i].user ? "user" : "assistant", chat[i].t});
    if (chat.empty()) say("Merhaba! Ben Guvercin Bot, bu sistemin asistaniyim. Uygulama acabilir, komut calistirabilir, not alabilirim. 'yardim' yaz.");
  }
  void save() { FILE* f = fopen(histFile.c_str(), "w"); if (!f) return; size_t s = chat.size() > 60 ? chat.size() - 60 : 0; for (size_t i = s; i < chat.size(); i++) { std::string t = chat[i].t; for (auto& ch : t) if (ch == '\n') ch = '\x1f'; fprintf(f, "%c|%s\n", chat[i].user ? 'u' : 'b', t.c_str()); } fclose(f); }
  void say(const std::string& t) { chat.push_back({false, clean(t)}); scroll = 0; save(); }
  void remember(const std::string& u, const std::string& a) { hist.push_back({"user", u}); hist.push_back({"assistant", a}); while (hist.size() > 24) hist.erase(hist.begin()); }
  std::string prompt();
  bool local(const std::string& raw);
  void act(const std::string& a, const std::string& p);
  void queue(const std::string& a, const std::string& p);
  void confirm(bool yes);
  void send(const std::string& text);
  void startReq(const std::string& text);
  void handleReply(const std::string& out);
  void draw(Canvas&, Rect) override;
  void down(int, int) override;
  void key(int, int) override;
  void wheel(int d) override { scroll = std::max(0, scroll + d); }
  void tick() override { if (busy && req && req->st == 2) { busy = false; handleReply(req->out); } }
};

// ---------- Kabuk ----------
struct Win { int id = 0, x = 0, y = 0, w = 0, h = 0, sx = 0, sy = 0, sw = 0, sh = 0; bool max = false, min = false; std::unique_ptr<App> app; };
struct Entry { const char* name; char letter; uint32_t col; std::function<std::unique_ptr<App>()> make; };
struct Shell {
  int W, H, mx, my, nid = 1, dragId = 0, dox = 0, doy = 0, pal = 0; std::vector<Win> wins; Canvas wall; int wallPal = -1; std::vector<Entry> entries; bool quit = false;
  static const int TB = 44, TT = 30;
  Shell(int w, int h) : W(w), H(h), mx(w / 2), my(h / 2), wall(w, h) {
    entries = {{"Dosyalar", 'D', 0x3b82f6, [] { return std::make_unique<Files>(); }}, {"Terminal", 'T', 0x334155, [] { return std::make_unique<Term>(); }},
               {"Notlar", 'N', 0xeab308, [] { return std::make_unique<Notes>(); }}, {"Gorevler", 'G', 0x22c55e, [] { return std::make_unique<Tasks>(); }},
               {"Yilan", 'Y', 0x16a34a, [] { return std::make_unique<Snake>(); }}, {"Hesap", 'H', 0x8b5cf6, [] { return std::make_unique<Calc>(); }},
               {"Ayarlar", 'A', 0x64748b, [] { return std::make_unique<Settings>(); }}, {"Asistan", 'S', 0xc58b93, [] { return std::make_unique<Assistant>(); }}};
  }
  Rect icon(int i) { int cols = std::max(1, (W - 48) / 104); return {24 + (i % cols) * 104, 160 + (i / cols) * 104, 96, 96}; }
  void launch(std::unique_ptr<App> a) {
    for (auto& w : wins) if (w.app->title == a->title && a->title.compare(0, 5, "Notla") != 0) { w.min = false; raise(w.id); return; }
    Win w; w.id = nid++; w.app = std::move(a); w.app->sh = this; int n = (int)wins.size(); w.w = std::min(w.app->dw, W); w.h = std::min(w.app->dh + TT, H - TB);
    w.x = std::min(60 + n * 30, std::max(0, W - w.w)); w.y = std::min(40 + n * 26, std::max(0, H - TB - w.h)); wins.push_back(std::move(w));
  }
  void raise(int id) { for (size_t i = 0; i < wins.size(); i++) if (wins[i].id == id) { Win t = std::move(wins[i]); wins.erase(wins.begin() + i); wins.push_back(std::move(t)); return; } }
  void openNote(const std::string& p) { launch(std::make_unique<Notes>(p)); }
  void toggleMax(Win& w) { if (!w.max) { w.sx = w.x; w.sy = w.y; w.sw = w.w; w.sh = w.h; w.x = 0; w.y = 0; w.w = W; w.h = H - TB; } else { w.x = w.sx; w.y = w.sy; w.w = w.sw; w.h = w.sh; } w.max = !w.max; }
  void mouseMove(int x, int y) { mx = std::max(0, std::min(W - 1, x)); my = std::max(0, std::min(H - 1, y)); if (dragId) for (auto& w : wins) if (w.id == dragId) { w.x = mx - dox; w.y = std::max(0, std::min(H - TB - TT, my - doy)); } }
  void mouseUp() { dragId = 0; }
  void mouseDown() {
    int x = mx, y = my;
    if (y >= H - TB) { if (x < 110) { for (auto& w : wins) w.min = true; return; } if (x < 208) { openByAlias("asistan"); return; } int bx = 214; for (size_t i = 0; i < wins.size(); i++, bx += 134) if (x >= bx && x < bx + 128) { int id = wins[i].id; wins[i].min = false; raise(id); return; } return; }
    for (int i = (int)wins.size() - 1; i >= 0; i--) {
      Win& w = wins[i]; if (w.min || !Rect{w.x, w.y, w.w, w.h}.in(x, y)) continue; raise(w.id); Win& t = wins.back();
      if (y < t.y + TT) { int bx = t.x + t.w - 32; if (x >= bx) { wins.pop_back(); return; } bx -= 32; if (x >= bx) { toggleMax(t); return; } bx -= 32; if (x >= bx) { t.min = true; return; } if (!t.max) { dragId = t.id; dox = x - t.x; doy = y - t.y; } return; }
      t.app->down(x, y); return;
    }
    if (Rect{W / 2 - 200, 112, 400, 30}.in(x, y)) { openByAlias("asistan"); return; }
    for (size_t i = 0; i < entries.size(); i++) if (icon((int)i).in(x, y)) { launch(entries[i].make()); return; }
  }
  App* focus() { for (int i = (int)wins.size() - 1; i >= 0; i--) if (!wins[i].min) return wins[i].app.get(); return nullptr; }
  void key(int code, int ch) {
    if (code == K_F1) { openByAlias("asistan"); return; }
    App* a = focus(); if (!a && ch >= 32 && ch < 127) { openByAlias("asistan"); a = focus(); }
    if (a) a->key(code, ch);
  }
  void raiseApp(App* a) { for (auto& w : wins) if (w.app.get() == a) { int id = w.id; raise(id); return; } }
  bool openByAlias(const std::string& al) { int i = entryFor(norm(al)); if (i < 0 || i >= (int)entries.size()) return false; launch(entries[i].make()); return true; }
  bool closeByAlias(const std::string& al) {
    int i = entryFor(norm(al)); if (i < 0) return false; std::string k = norm(entries[i].name).substr(0, 4);
    for (size_t j = 0; j < wins.size(); j++) if (norm(wins[j].app->title).compare(0, 4, k) == 0) { wins.erase(wins.begin() + j); return true; }
    return false;
  }
  void appendNote(const std::string& t) {
    std::string p = "/root/notlar.txt"; FILE* f = fopen(p.c_str(), "a"); if (!f) { p = "/tmp/notlar.txt"; f = fopen(p.c_str(), "a"); }
    if (f) { fputs((t + "\n").c_str(), f); fclose(f); }
    for (size_t j = 0; j < wins.size(); j++) if (wins[j].app->title.compare(0, 8, "Notlar -") == 0) { wins.erase(wins.begin() + j); break; }
    openNote(p);
  }
  std::string status() {
    time_t tt = time(0); tm lt; localtime_r(&tt, &lt); char b[16]; strftime(b, sizeof b, "%H:%M", &lt); std::string s = std::string("Saat ") + b + ", ekran " + std::to_string(W) + "x" + std::to_string(H) + ", acik pencereler: ";
    for (auto& w : wins) s += w.app->title + (w.min ? "(kucuk) " : " "); return s;
  }
  void wheel(int d) { if (App* a = focus()) a->wheel(d); }
  void tick() { for (auto& w : wins) w.app->tick(); }
  void paintWall() {
    static const uint32_t P[3][5] = {{0x14304d, 0xf2b265, 0x1d5577, 0x16445f, 0x0f3249}, {0x0b1020, 0xc9d6ff, 0x18234a, 0x121a3a, 0x0c1229}, {0x12332a, 0xf4e3a1, 0x1f5a45, 0x194a39, 0x113a2d}};
    wall.fill({0, 0, W, H}, P[pal][0]); int r = H / 7, cx = W * 3 / 4, cy = H / 3;
    for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) if (x * x + y * y <= r * r) wall.fill({cx + x, cy + y, 1, 1}, P[pal][1]);
    for (int l = 0; l < 3; l++) for (int x = 0; x < W; x++) { double fx = (double)x / W; int y0 = (int)(H * (0.60 + l * 0.12) + H * 0.04 * std::sin(fx * 6.0 + l * 1.7) + H * 0.02 * std::sin(fx * 13.0 + l)); wall.fill({x, y0, 1, H - y0}, P[pal][2 + l]); }
    wallPal = pal;
  }
  void draw(Canvas& c) {
    if (wallPal != pal) paintWall(); c.px = wall.px; c.clip = {0, 0, W, H};
    time_t tt = time(0); tm lt; localtime_r(&tt, &lt); char b[32]; strftime(b, sizeof b, "%H:%M", &lt); c.text(W / 2 - 80, 22, b, 0xffffff, 4); strftime(b, sizeof b, "%d.%m.%Y", &lt); c.text(W / 2 - tw(b) / 2, 90, b, 0xe6edf3, 1);
    c.rrect({W / 2 - 200, 112, 400, 30}, 15, 0x0b1118); c.text(W / 2 - 184, 119, "Asistan'a yaz veya komut ver...", MUT);
    for (size_t i = 0; i < entries.size(); i++) { Rect r = icon((int)i); c.rrect({r.x + 20, r.y + 4, 56, 56}, 14, entries[i].col); c.text(r.x + 48 - 12, r.y + 12, std::string(1, entries[i].letter), 0xffffff, 3); c.text(r.x + 48 - tw(entries[i].name) / 2, r.y + 68, entries[i].name, 0xffffff); }
    for (auto& w : wins) {
      if (w.min) continue; c.fill({w.x + 6, w.y + 8, w.w, w.h}, 0x0a0f16); c.fill({w.x, w.y, w.w, w.h}, LINE); c.fill({w.x + 1, w.y + 1, w.w - 2, TT - 1}, BAR);
      c.text(w.x + 12, w.y + 7, cut(w.app->title, (w.w - 120) / 8), FG); int bx = w.x + w.w - 32; c.fill({bx, w.y + 1, 31, TT - 1}, RED); c.text(bx + 11, w.y + 7, "×", 0xffffff);
      c.text(bx - 32 + 11, w.y + 7, "□", FG); c.text(bx - 64 + 11, w.y + 7, "–", FG);
      Rect cr{w.x + 1, w.y + TT, w.w - 2, w.h - TT - 1}; c.clip = cr; c.fill(cr, BG); w.app->draw(c, cr); c.clip = {0, 0, W, H};
    }
    c.fill({0, H - TB, W, TB}, 0x0a1624); c.fill({0, H - TB, W, 1}, 0x1f3348); c.rrect({8, H - TB + 7, 94, 30}, 8, ACC); c.text(8 + (94 - 48) / 2, H - TB + 14, "MiniOS", 0x07201c);
    c.rrect({110, H - TB + 7, 96, 30}, 8, 0xc58b93); c.text(110 + 20, H - TB + 14, "Asistan", 0x2e2432);
    int bx = 214; for (auto& w : wins) { c.rrect({bx, H - TB + 7, 128, 30}, 8, (&w == &wins.back() && !w.min) ? LINE : BAR); c.text(bx + 8, H - TB + 14, cut(w.app->title, 14), w.min ? MUT : FG); bx += 134; }
    strftime(b, sizeof b, "%H:%M", &lt); c.text(W - 56, H - TB + 14, b, FG);
    static const char* A[] = {"X........... ", "XX.......... ", "XOX......... ", "XOOX........ ", "XOOOX....... ", "XOOOOX...... ", "XOOOOOX..... ", "XOOOOOOX.... ", "XOOOOOOOX... ", "XOOOOOXXXX.. ", "XOXXOOX..... ", "XX..XOOX.... ", "X...XOOX.... ", "....XOOX.... ", ".....XX..... "};
    for (int y = 0; y < 15; y++) for (int x = 0; x < 12; x++) { char ch = A[y][x]; if (ch == 'X') c.fill({mx + x, my + y, 1, 1}, 0); else if (ch == 'O') c.fill({mx + x, my + y, 1, 1}, 0xffffff); }
  }
};
void Files::openFile(const std::string& p) { if (sh) sh->openNote(p); }
void Settings::draw(Canvas& c, Rect r) {
  R = r; c.fill(r, BG); utsname u; uname(&u); c.text(r.x + 12, r.y + 12, std::string("Cekirdek: ") + u.sysname + " " + u.release, FG); c.text(r.x + 12, r.y + 32, "Ekran: " + std::to_string(sh->W) + "x" + std::to_string(sh->H), FG);
  c.text(r.x + 12, r.y + 64, "Duvar kagidi", MUT); const char* n[3] = {"Gun batimi", "Gece", "Orman"}; for (int i = 0; i < 3; i++) button(c, {r.x + 12 + i * 120, r.y + 88, 112, 30}, n[i], sh->pal == i);
  button(c, {r.x + 12, r.y + 150, 150, 34}, "Yeniden baslat"); button(c, {r.x + 176, r.y + 150, 150, 34}, "Kapat");
}
void Settings::down(int x, int y) {
  for (int i = 0; i < 3; i++) if (Rect{R.x + 12 + i * 120, R.y + 88, 112, 30}.in(x, y)) sh->pal = i;
  if (Rect{R.x + 12, R.y + 150, 150, 34}.in(x, y)) { if (system("reboot") != 0) sh->quit = true; }
  if (Rect{R.x + 176, R.y + 150, 150, 34}.in(x, y)) { if (system("poweroff") != 0) sh->quit = true; }
}


// ---------- Asistan metotlari ----------
std::string Assistant::prompt() {
  std::string t = "Sen Güvercin Bot adında, bu işletim sisteminin ana yapay zeka asistanısın (Siri gibi). Bir yapay zeka olduğunu biliyorsun ama robot gibi değil, doğal konuş. Aynı kalıpları tekrar etme, önceki mesajları dikkate al. Hangi modelle çalıştığın sorulursa uydurma: Groq üzerinde bir dil modeliyle çalıştığını söyle. ";
  t += name.empty() ? "Karşındaki kişinin adını bilmiyorsun, tahmin etme, nötr 'sen' diye konuş. " : "Karşındaki kişi adının " + name + " olduğunu söyledi, ona adıyla hitap et. ";
  t += "Seni kimin yazdığı sorulursa sadece 'Beni Türk bir mühendis yazdı' de, adını paylaşma. ";
  if (mode == 1) t += "Şu an CİDDİ modasın: teknik, odaklı, profesyonel ol; gereksiz emoji ve şaka yok. ";
  else if (mode == 2) t += "Şu an EĞLENCELİ modasın: şakacı, enerjik ve oyuncu ol, ama kaba olma. ";
  else if (mode == 3) t += "Şu an AGENT modasın: isteği kısaca adımlara böl, gerekirse etiketlerle uygula, sonunda kısaca özetle. Belirsizse kısa bir soru sor. ";
  else t += "Şu an NORMAL modasın: gündelik, samimi, kısa konuş (1-4 cümle). ";
  t += "Ekranda yalnızca düz yazı gösterilir: emoji ve markdown kullanma, en fazla 5-6 satır yaz. "
       "İşletim sistemini GERÇEKTEN kontrol edebilirsin. Gerektiğinde cevabına şu etiketlerden birini aynen ekle (kullanıcı görmez, otomatik çalışır, en fazla 3 tane): "
       "[[EYLEM:ac:UYGULAMA]] uygulama açar (Dosyalar, Terminal, Notlar, Gorevler, Yilan, Hesap, Ayarlar); [[EYLEM:kapat:UYGULAMA]]; "
       "[[EYLEM:komut:KABUK_KOMUTU]] kabukta komut çalıştırır (kullanıcı onayından sonra, çıktıyı sonra (sistem) mesajıyla alırsın); "
       "[[EYLEM:notyaz:METIN]] nota ekler; [[EYLEM:dosyaoku:YOL]] dosyanın başını gösterir; [[EYLEM:sonlandir:PID]]; [[EYLEM:duvar:0]] (0 gün batımı, 1 gece, 2 orman); [[EYLEM:yenidenbaslat]]; [[EYLEM:sistemkapat]]. "
       "Yapamayacağın bir şeyi yapabiliyormuş gibi davranma. Güncel durum: " + sh->status() + ".";
  return t;
}
bool Assistant::local(const std::string& raw) {
  std::string n = norm(raw); auto has = [&](const char* w) { return n.find(w) != std::string::npos; };
  if (has("yardim") || n == "neler yapabilirsin") { say("Ornekler: 'terminal ac', 'notlara yaz: sut al', 'saat kac', 'bellek ne kadar', 'duvar kagidi gece', 'komut: ls /', 'sistemi yeniden baslat'. Anahtar butonuyla Groq anahtari girersen her konuda sohbet ederim."); return true; }
  size_t p = n.find("benim adim "); if (p != std::string::npos) { name = n.substr(p + 11); size_t sp = name.find(' '); if (sp != std::string::npos) name = name.substr(0, sp); if (!name.empty()) name[0] = (char)toupper(name[0]); say("Memnun oldum " + name + "!"); return true; }
  if (has("saat kac")) { say(sh->status().substr(0, sh->status().find(','))); return true; }
  if (has("tarih") || has("bugun gunlerden")) { time_t tt = time(0); tm lt; localtime_r(&tt, &lt); char b[40]; strftime(b, sizeof b, "%d.%m.%Y", &lt); say(std::string("Bugun ") + b); return true; }
  if (has("bellek") || has(" ram")) { struct sysinfo si; if (sysinfo(&si) == 0) { char b[96]; double tot = si.totalram * (double)si.mem_unit / 1048576, fr = si.freeram * (double)si.mem_unit / 1048576; snprintf(b, sizeof b, "RAM: %.0f MB kullaniliyor, toplam %.0f MB.", tot - fr, tot); say(b); } return true; }
  if (has("duvar")) { int w = has("gece") ? 1 : has("orman") ? 2 : (has("gun batimi") || has("gunes")) ? 0 : -1; if (w >= 0) { sh->pal = w; say("Duvar kagidini degistirdim."); return true; } }
  if (has("yeniden baslat")) { queue("yenidenbaslat", ""); return true; }
  if (has("sistemi kapat") || has("bilgisayari kapat") || n == "kapat sistemi") { queue("sistemkapat", ""); return true; }
  for (const char* pre : {"notlara yaz", "not al", "not yaz", "nota yaz"}) { size_t q = n.find(pre); if (q == 0) { size_t cpos = raw.find(':'); std::string t = cpos != std::string::npos ? raw.substr(cpos + 1) : raw.substr(std::min(raw.size(), strlen(pre) + 1)); while (!t.empty() && t[0] == ' ') t.erase(0, 1); if (!t.empty()) { queue("notyaz", t); return true; } } }
  if (n.rfind("calistir ", 0) == 0 || n.rfind("komut:", 0) == 0 || (n.rfind("komut ", 0) == 0 && !has("satiri"))) { size_t cpos = raw.find(n[0] == 'k' && n[5] == ':' ? ':' : ' '); std::string c = raw.substr(cpos + 1); while (!c.empty() && c[0] == ' ') c.erase(0, 1); if (!c.empty() && !(n.rfind("calistir ", 0) == 0 && entryFor(norm(c)) >= 0)) { queue("komut", c); return true; } }
  int e = entryFor(n);
  if (e >= 0 && (has("kapat") || has("sonlandir"))) { queue("kapat", n); return true; }
  if (e >= 0 && (has(" ac") || n.rfind("ac ", 0) == 0 || (n.size() >= 2 && n.compare(n.size() - 2, 2, "ac") == 0) || has("baslat") || has("calistir") || has("goster") || has("listele"))) { queue("ac", n); return true; }
  return false;
}
void Assistant::queue(const std::string& a, const std::string& p) {
  bool risky = a == "komut" || a == "sonlandir" || a == "yenidenbaslat" || a == "sistemkapat";
  if (risky && needConfirm) { std::string d = a == "komut" ? "Komut calistir: " + p : a == "sonlandir" ? "Sureci sonlandir: PID " + p : a == "yenidenbaslat" ? "Sistemi yeniden baslat" : "Sistemi kapat"; pend.push_back({a, p, d}); }
  else act(a, p);
}
void Assistant::confirm(bool yes) { if (pend.empty()) return; Pend p = pend.front(); pend.erase(pend.begin()); if (yes) act(p.act, p.par); else say("Iptal ettim."); }
void Assistant::act(const std::string& a, const std::string& p) {
  if (a == "ac") { bool ok = sh->openByAlias(p); sh->raiseApp(this); say(ok ? "Actim." : "Bu uygulamayi bulamadim: " + p); }
  else if (a == "kapat") say(sh->closeByAlias(p) ? "Kapattim." : "Acik bir pencere bulamadim: " + p);
  else if (a == "notyaz") { sh->appendNote(p); sh->raiseApp(this); say("Nota ekledim."); }
  else if (a == "duvar") { sh->pal = std::max(0, std::min(2, atoi(p.c_str()))); say("Duvar kagidini degistirdim."); }
  else if (a == "dosyaoku") { FILE* f = fopen(p.c_str(), "r"); if (!f) { say("Dosya acilamadi: " + p); return; } char b[900]; size_t n = fread(b, 1, sizeof b - 1, f); b[n] = 0; fclose(f); say(std::string(b)); }
  else if (a == "komut") { auto o = runCmd(p, 10); std::string s; for (size_t i = 0; i < o.size() && i < 25; i++) s += o[i] + "\n"; if (s.empty()) s = "(cikti yok)"; say(s); hist.push_back({"user", "(sistem) komut ciktisi: " + s.substr(0, 700)}); }
  else if (a == "sonlandir") { int pid = atoi(p.c_str()); if (pid > 1 && pid != getpid()) { kill(pid, SIGTERM); say("Sonlandirma sinyali gonderdim."); } else say("Bu sureci sonlandiramam."); }
  else if (a == "yenidenbaslat") { say("Yeniden baslatiyorum..."); if (system("reboot") != 0) sh->quit = true; }
  else if (a == "sistemkapat") { say("Kapatiyorum..."); if (system("poweroff") != 0) sh->quit = true; }
  else say("Bilmedigim bir eylem: " + a);
}
void Assistant::send(const std::string& text) {
  if (busy) return; chat.push_back({true, clean(text)}); scroll = 0; save(); lastUser = text;
  size_t before = chat.size(); if (local(text)) { if (chat.size() > before) remember(text, chat.back().t); return; }
  if (!pend.empty()) return;
  if (apiKey.empty()) { std::string n = norm(text); say(n.find("merhaba") != std::string::npos || n.find("selam") != std::string::npos ? "Merhaba! Nasil yardimci olabilirim?" : n.find("nasilsin") != std::string::npos ? "Iyiyim, tesekkurler! Sen nasilsin?" : n.find("tesekkur") != std::string::npos ? "Rica ederim." : "Bunu tam anlayamadim. Anahtar butonuyla Groq API anahtari girersen her konuda sohbet edebilirim. 'yardim' yaz."); return; }
  startReq(text);
}
void Assistant::startReq(const std::string& text) {
  std::string body = "{\"model\":\"openai/gpt-oss-120b\",\"max_tokens\":2000,\"reasoning_effort\":\"low\",\"messages\":[{\"role\":\"system\",\"content\":\"" + jsonEsc(prompt()) + "\"}";
  for (size_t i = hist.size() > 20 ? hist.size() - 20 : 0; i < hist.size(); i++) body += ",{\"role\":\"" + hist[i].first + "\",\"content\":\"" + jsonEsc(hist[i].second) + "\"}";
  body += ",{\"role\":\"user\",\"content\":\"" + jsonEsc(text) + "\"}]}";
  auto rq = std::make_shared<Req>(); req = rq; busy = true; std::string k = apiKey; for (auto& c : k) if (c == '"' || c == '\n' || c == '\\') c = ' ';
  std::string fk = getenv("MINIOS_FAKE_LLM") ? getenv("MINIOS_FAKE_LLM") : "";
  std::thread([rq, body, k, fk]() {
    if (!fk.empty()) { usleep(300000); rq->out = "{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"" + jsonEsc(fk) + "\"}}]}"; rq->st = 2; return; }
    char tag[64]; snprintf(tag, sizeof tag, "%d_%lld", (int)getpid(), (long long)nowms()); std::string cfg = std::string("/tmp/.mo_c") + tag, bf = std::string("/tmp/.mo_b") + tag;
    writeSecret(cfg, "header = \"Authorization: Bearer " + k + "\"\n"); writeSecret(bf, body);
    auto L = runCmd("curl -sS -m 45 -K " + cfg + " -H 'Content-Type: application/json' --data-binary @" + bf + " https://api.groq.com/openai/v1/chat/completions 2>&1; rm -f " + cfg + " " + bf, 50);
    std::string o; for (auto& l : L) o += l + "\n"; rq->out = o; rq->st = 2;
  }).detach();
}
void Assistant::handleReply(const std::string& out) {
  bool ok; std::string txt = extractReply(out, ok); if (!ok) { say(txt); return; }
  std::vector<std::pair<std::string, std::string>> acts;
  for (size_t p; (p = txt.find("[[EYLEM:")) != std::string::npos;) { size_t e = txt.find("]]", p); if (e == std::string::npos) break; std::string in2 = txt.substr(p + 8, e - p - 8); size_t c = in2.find(':'); acts.push_back({in2.substr(0, c), c == std::string::npos ? "" : in2.substr(c + 1)}); txt.erase(p, e + 2 - p); }
  std::string t = clean(txt); while (!t.empty() && (t.back() == ' ' || t.back() == '\n')) t.pop_back();
  if (!t.empty()) { say(t); remember(lastUser, t); }
  for (size_t i = 0; i < acts.size() && i < 3; i++) queue(acts[i].first, acts[i].second);
}
void Assistant::draw(Canvas& c, Rect r) {
  R = r; c.fill(r, BG); static const char* M[4] = {"Normal", "Ciddi", "Eğlenceli", "Agent"};
  for (int i = 0; i < 4; i++) { rMode[i] = {r.x + 8 + i * 86, r.y + 6, 82, 26}; button(c, rMode[i], M[i], mode == i); }
  rKey = {r.x + 8, r.y + 36, 84, 26}; rConf = {r.x + 100, r.y + 36, 118, 26}; rClear = {r.x + 226, r.y + 36, 80, 26};
  button(c, rKey, "Anahtar", !apiKey.empty()); button(c, rConf, needConfirm ? "Onay: açık" : "Onay: kapalı"); button(c, rClear, "Temizle");
  c.text(r.x + 316, r.y + 41, busy ? "düşünüyor..." : apiKey.empty() ? "AI kapalı" : "AI açık", busy ? ACC : MUT);
  int top = r.y + 68, bottom = r.y + r.h - 34 - (pend.empty() ? 0 : 40), rows = std::max(1, (bottom - top) / 16), cols = (r.w - 20) / 8;
  std::vector<std::pair<std::string, uint32_t>> L;
  for (auto& m : chat) wrapInto(L, (m.user ? "Sen: " : "Asistan: ") + m.t, cols, m.user ? ACC : FG);
  int total = (int)L.size(), start = std::max(0, total - rows - scroll); scroll = std::min(scroll, std::max(0, total - rows));
  for (int i = start; i < total && i < start + rows; i++) c.text(r.x + 10, top + (i - start) * 16, L[i].first, L[i].second);
  if (!pend.empty()) { int y = bottom + 2; c.fill({r.x + 4, y, r.w - 8, 36}, SIDE); c.text(r.x + 10, y + 10, cut("Onay gerekli: " + pend[0].desc, (r.w - 200) / 8), 0xf2b265); rOk = {r.x + r.w - 170, y + 5, 80, 26}; rNo = {r.x + r.w - 84, y + 5, 76, 26}; button(c, rOk, "Onayla", true); button(c, rNo, "İptal"); }
  std::string shown = keyMode ? "Groq anahtari: " + std::string(in.size(), '*') : "> " + in; c.text(r.x + 10, r.y + r.h - 24, cut(shown + ((nowms() / 500) % 2 ? "_" : " "), cols), keyMode ? 0xf2b265 : FG);
}
void Assistant::down(int x, int y) {
  for (int i = 0; i < 4; i++) if (rMode[i].in(x, y)) { mode = i; static const char* N[4] = {"Normal moda gectim.", "Ciddi moda gectim.", "Eglenceli moda gectim!", "Agent moduna gectim."}; say(N[i]); }
  if (rKey.in(x, y)) { keyMode = true; in.clear(); }
  if (rConf.in(x, y)) needConfirm = !needConfirm;
  if (rClear.in(x, y)) { chat.clear(); hist.clear(); pend.clear(); save(); say("Sohbeti temizledim."); }
  if (!pend.empty()) { if (rOk.in(x, y)) confirm(true); else if (rNo.in(x, y)) confirm(false); }
}
void Assistant::key(int code, int ch) {
  if (code == K_ESC) { if (keyMode) { keyMode = false; in.clear(); } else if (!pend.empty()) confirm(false); return; }
  if (code == K_UP) { scroll++; return; } if (code == K_DOWN) { scroll = std::max(0, scroll - 1); return; }
  if (ch == '\n') {
    if (!pend.empty() && in.empty()) { confirm(true); return; }
    if (keyMode) { apiKey = in; keyMode = false; in.clear(); say(apiKey.empty() ? "Anahtar silindi." : "Anahtar sadece bellekte tutuluyor (diske yazilmaz). AI acik."); return; }
    if (!in.empty()) { std::string t = in; in.clear(); send(t); } return;
  }
  if (ch == '\b') { if (!in.empty()) in.pop_back(); } else if (ch >= 32 && ch < 127 && in.size() < 300) in += (char)ch;
}

// ---------- Klavye tablolari (US) ----------
static int mapKey(int code, bool shift) {
  static const char* N = "\0\0" "1234567890-=\b\t" "qwertyuiop[]\n\0" "asdfghjkl;'`\0\\" "zxcvbnm,./\0*\0 ";
  static const char* S = "\0\0" "!@#$%^&*()_+\b\t" "QWERTYUIOP{}\n\0" "ASDFGHJKL:\"~\0|" "ZXCVBNM<>?\0*\0 ";
  if (code == KEY_ESC) return K_ESC; if (code == KEY_F1) return K_F1;
  if (code == KEY_UP) return K_UP; if (code == KEY_DOWN) return K_DOWN; if (code == KEY_LEFT) return K_LEFT; if (code == KEY_RIGHT) return K_RIGHT;
  if (code < 0 || code > 57) return 0; return (unsigned char)(shift ? S : N)[code];
}

// ---------- Gercek cihaz: framebuffer + evdev ----------
struct Dev { int fd; bool abs; int minx, maxx, miny, maxy, ax, ay; };
static void runReal() {
  int fb = open("/dev/fb0", O_RDWR); if (fb < 0) { perror("/dev/fb0"); exit(1); }
  fb_var_screeninfo vi; fb_fix_screeninfo fi; ioctl(fb, FBIOGET_VSCREENINFO, &vi); ioctl(fb, FBIOGET_FSCREENINFO, &fi);
  uint8_t* mem = (uint8_t*)mmap(0, fi.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, fb, 0); int W = vi.xres, H = vi.yres, bpp = vi.bits_per_pixel;
  Shell sh(W, H); Canvas cv(W, H); std::vector<Dev> devs;
  for (int i = 0; i < 32; i++) { char p[64]; snprintf(p, sizeof p, "/dev/input/event%d", i); int fd = open(p, O_RDONLY | O_NONBLOCK); if (fd < 0) continue; Dev d{fd, false, 0, 1, 0, 1, 0, 0};
    uint8_t ab[8] = {0}; ioctl(fd, EVIOCGBIT(EV_ABS, sizeof ab), ab); if (ab[ABS_X / 8] & (1 << (ABS_X % 8))) { input_absinfo a; if (ioctl(fd, EVIOCGABS(ABS_X), &a) == 0) { d.abs = true; d.minx = a.minimum; d.maxx = a.maximum; } if (ioctl(fd, EVIOCGABS(ABS_Y), &a) == 0) { d.miny = a.minimum; d.maxy = a.maximum; } }
    devs.push_back(d); }
  bool shift = false; signal(SIGPIPE, SIG_IGN); signal(SIGCHLD, SIG_DFL);
  while (!sh.quit) {
    std::vector<pollfd> pf; for (auto& d : devs) pf.push_back({d.fd, POLLIN, 0}); poll(pf.data(), pf.size(), 30);
    for (size_t k = 0; k < devs.size(); k++) { Dev& d = devs[k]; input_event e;
      while (read(d.fd, &e, sizeof e) == (ssize_t)sizeof e) {
        if (e.type == EV_REL) { if (e.code == REL_X) sh.mouseMove(sh.mx + e.value, sh.my); else if (e.code == REL_Y) sh.mouseMove(sh.mx, sh.my + e.value); else if (e.code == REL_WHEEL) sh.wheel(e.value); }
        else if (e.type == EV_ABS) { if (e.code == ABS_X) d.ax = (int)((int64_t)(e.value - d.minx) * W / std::max(1, d.maxx - d.minx)); else if (e.code == ABS_Y) d.ay = (int)((int64_t)(e.value - d.miny) * H / std::max(1, d.maxy - d.miny)); sh.mouseMove(d.ax, d.ay); }
        else if (e.type == EV_KEY) {
          if (e.code == BTN_LEFT || e.code == BTN_TOUCH) { if (e.value) sh.mouseDown(); else sh.mouseUp(); }
          else if (e.code == KEY_LEFTSHIFT || e.code == KEY_RIGHTSHIFT) shift = e.value != 0;
          else if (e.value) { int ch = mapKey(e.code, shift); if (ch >= K_UP) sh.key(ch, 0); else if (ch) sh.key(0, ch); }
        }
      } }
    sh.tick(); sh.draw(cv);
    for (int y = 0; y < H; y++) { uint8_t* row = mem + (size_t)y * fi.line_length; if (bpp == 32) memcpy(row, &cv.px[(size_t)y * W], (size_t)W * 4); else if (bpp == 16) for (int x = 0; x < W; x++) { uint32_t c = cv.px[(size_t)y * W + x]; ((uint16_t*)row)[x] = ((c >> 8) & 0xF800) | ((c >> 5) & 0x07E0) | ((c >> 3) & 0x1F); } }
  }
}

// ---------- Test modu ----------
static void runTest(int W, int H) {
  Shell sh(W, H); Canvas cv(W, H); char line[512];
  while (fgets(line, sizeof line, stdin)) {
    char cmd[32] = {0}, a[400] = {0}; int x, y; if (sscanf(line, "%31s", cmd) < 1) continue; const char* rest = line + strlen(cmd); while (*rest == ' ') rest++;
    if (!strcmp(cmd, "click") && sscanf(rest, "%d %d", &x, &y) == 2) { sh.mouseMove(x, y); sh.mouseDown(); sh.mouseUp(); }
    else if (!strcmp(cmd, "move") && sscanf(rest, "%d %d", &x, &y) == 2) sh.mouseMove(x, y);
    else if (!strcmp(cmd, "down")) sh.mouseDown(); else if (!strcmp(cmd, "up")) sh.mouseUp();
    else if (!strcmp(cmd, "type")) { std::string s = rest; while (!s.empty() && s.back() == '\n') s.pop_back(); for (char ch : s) sh.key(0, ch); }
    else if (!strcmp(cmd, "esc")) sh.key(K_ESC, 0); else if (!strcmp(cmd, "f1")) sh.key(K_F1, 0);
    else if (!strcmp(cmd, "enter")) sh.key(0, '\n'); else if (!strcmp(cmd, "up_key")) sh.key(K_UP, 0); else if (!strcmp(cmd, "right_key")) sh.key(K_RIGHT, 0);
    else if (!strcmp(cmd, "wait") && sscanf(rest, "%d", &x) == 1) { g_fake += x; usleep(x * 1000); sh.tick(); }
    else if (!strcmp(cmd, "shot") && sscanf(rest, "%399s", a) == 1) { sh.tick(); sh.draw(cv); FILE* f = fopen(a, "wb"); fprintf(f, "P6\n%d %d\n255\n", W, H); for (uint32_t c : cv.px) { uint8_t rgb[3] = {(uint8_t)(c >> 16), (uint8_t)(c >> 8), (uint8_t)c}; fwrite(rgb, 1, 3, f); } fclose(f); }
  }
}

int main(int argc, char** argv) {
  srand(time(0));
  if (argc >= 4 && !strcmp(argv[1], "--test")) { runTest(atoi(argv[2]), atoi(argv[3])); return 0; }
  runReal(); return 0;
}
