MINIOS_SHELL_VERSION = 1.0
MINIOS_SHELL_SITE = $(BR2_EXTERNAL_MINIOS_PATH)/src
MINIOS_SHELL_SITE_METHOD = local

define MINIOS_SHELL_BUILD_CMDS
	$(TARGET_CXX) $(TARGET_CXXFLAGS) -std=c++17 -O2 -pthread -o $(@D)/minios-shell $(@D)/main.cpp $(TARGET_LDFLAGS)
endef

define MINIOS_SHELL_INSTALL_TARGET_CMDS
	$(INSTALL) -D -m 0755 $(@D)/minios-shell $(TARGET_DIR)/usr/bin/minios-shell
endef

$(eval $(generic-package))
