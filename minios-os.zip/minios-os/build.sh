#!/bin/sh
# Gerekli: git make gcc g++ patch cpio unzip rsync bc wget python3 (build-essential)
set -e
cd "$(dirname "$0")"
TOP="$(pwd)"
[ -d buildroot ] || git clone --depth 1 --branch 2025.02 https://gitlab.com/buildroot.org/buildroot.git
cd buildroot
make BR2_EXTERNAL="$TOP" qemu_x86_64_defconfig
./support/kconfig/merge_config.sh -m .config "$TOP/minios.fragment"
make olddefconfig
make -j"$(nproc)"
echo "Bitti. Calistirmak icin: ./run.sh"
