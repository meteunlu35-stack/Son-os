include $(sort $(wildcard $(BR2_EXTERNAL_MINIOS_PATH)/package/*/*.mk))
