#!/bin/sh
cd "$(dirname "$0")/buildroot/output/images"
KVM=""; [ -w /dev/kvm ] && KVM="-enable-kvm -cpu host"
qemu-system-x86_64 -M q35 $KVM -m 512M -smp 2 \
  -kernel bzImage -drive file=rootfs.ext2,format=raw,if=virtio \
  -append "rootwait root=/dev/vda rw console=ttyS0" \
  -vga std -device qemu-xhci -device usb-kbd -device usb-tablet \
  -nic user,model=virtio-net-pci -serial mon:stdio
